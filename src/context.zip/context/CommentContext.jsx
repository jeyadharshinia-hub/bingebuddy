import { createContext, useContext, useState } from "react";

const CommentContext = createContext();

export function CommentProvider({ children }) {
  const [comments, setComments] = useState(() => {
    return JSON.parse(localStorage.getItem("comments")) || [];
  });

  const addComment = (comment) => {
    const updated = [
      { ...comment, createdAt: Date.now() },
      ...comments,
    ];

    setComments(updated);
    localStorage.setItem("comments", JSON.stringify(updated));
  };

  return (
    <CommentContext.Provider value={{ comments, addComment }}>
      {children}
    </CommentContext.Provider>
  );
}

export const useComments = () => useContext(CommentContext);