import { createContext, useContext, useState } from "react";

const FilterContext = createContext();

export function FilterProvider({ children }) {
  // 🔥 Central filter state for entire app
  const [filters, setFilters] = useState({
    type: null,        // movie | tv | null
    language: null,    // en, ta, hi...
    region: null,      // US, IN, etc
    genre: null,       // genre id
    topRated: false,
    ongoing: false,
  });

  // 🔄 Update single filter key
  const updateFilter = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  // 🔁 Toggle filter (for chips)
  const toggleFilter = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: prev[key] === value ? null : value,
    }));
  };

  // 🧹 Clear all filters
  const clearFilters = () => {
    setFilters({
      type: null,
      language: null,
      region: null,
      genre: null,
      topRated: false,
      ongoing: false,
    });
  };

  // 🔢 Active filter count (for badge UI)
  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  return (
    <FilterContext.Provider
      value={{
        filters,
        setFilters,
        updateFilter,
        toggleFilter,
        clearFilters,
        activeFilterCount,
      }}
    >
      {children}
    </FilterContext.Provider>
  );
}

// Hook
export const useFilters = () => useContext(FilterContext);