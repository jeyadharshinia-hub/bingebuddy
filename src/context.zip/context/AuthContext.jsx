import { createContext, useState, useEffect } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  const saved = localStorage.getItem("user");

  if (!saved) return;

  let mounted = true;

  try {
    const parsed = JSON.parse(saved);

    if (mounted) {
      queueMicrotask(() => {
        setUser(parsed);
      });
    }
  } catch {
    localStorage.removeItem("user");
  }

  return () => {
    mounted = false;
  };
}, []);
  const login = (userData) => {
    setUser(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthContext;