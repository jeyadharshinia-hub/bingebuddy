import { createContext, useContext, useState } from "react";
import { useAuth } from "./AuthContext";

const WatchlistContext = createContext();

export function WatchlistProvider({ children }) {
  const { user } = useAuth();

  const [watchlist, setWatchlist] = useState(() => {
    return JSON.parse(localStorage.getItem("watchlist")) || [];
  });

  const toggleWatchlist = (item) => {
    if (!user) return false; // 🔥 IMPORTANT FIX

    const exists = watchlist.find((i) => i.id === item.id);

    let updated;
    if (exists) {
      updated = watchlist.filter((i) => i.id !== item.id);
    } else {
      updated = [...watchlist, item];
    }

    setWatchlist(updated);
    localStorage.setItem("watchlist", JSON.stringify(updated));

    return true;
  };

  const isInWatchlist = (id) => watchlist.some((i) => i.id === id);

  return (
    <WatchlistContext.Provider value={{ watchlist, toggleWatchlist, isInWatchlist }}>
      {children}
    </WatchlistContext.Provider>
  );
}

export const useWatchlist = () => useContext(WatchlistContext);